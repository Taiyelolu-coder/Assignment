import "./Footer.css"

function Footer() {
  

    return (
      <div className="FooterContent">
        <div className="text">
         <h1>Tools</h1>
         <nav>Generate your palettes</nav>
         <nav>Explore popular palettes</nav>
         <nav>Extract palette from image</nav>
         <nav>Contrast checker</nav>
         <nav>Preview palettes on designs</nav>
         <nav>Recolor your own design</nav>
         <nav>Color picker</nav>
         <nav>Browse free fonts</nav>
        </div>
        <div className="text">
          <h1>More</h1>
          <nav>List of colors <span>NEW</span></nav>
          <nav>Browse gradients</nav>
          <nav>Create a gradient</nav>
          <nav>Make a gradient palette</nav>
          <nav>Image converter</nav>
          <nav>Create a collage</nav>
          <nav>Font Generator</nav>
        </div>
        <div className="sub-text">
          <div>
          <h1>Jobs</h1>
          <nav>Find your next job</nav>
          <nav>Post a job</nav>
          </div>
          <div>
          <h1>Apps</h1>
          <nav>iOS App</nav>
          <nav>Android App</nav>
          <nav>Figma Plugin</nav>
          <nav>Adobe Extension <span>NEW</span></nav>
          <nav>Chrome Extension</nav>
          <nav>Instagram Page</nav>
          </div>
        </div>  
        <div className="text">
          <h1>Company</h1>
          <nav>Pricing</nav>
          <nav>License</nav>
          <nav>Terms of service</nav>
          <nav>Privacy policy</nav>
          <nav>Cookie policy</nav>
          <nav>Manage cookies</nav>
          <nav>Help center</nav>
          <nav>Advertise</nav>
          <nav>Affliate</nav>
          <nav>Contact</nav>
          
        </div>

       
      </div>
      
    )
  }
  
  export default Footer