function Apps2 (){
    return(
        <div></div>
    )
}

export default Apps2