import Home from "./Page/Home/Home"

function App() {
  

  return (
    <>
     <Home />
    </>
  )
}

export default App
